import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:latlong2/latlong.dart';
import 'dart:ui' as ui;
import '../../../../core/l10n/l10n.dart';
import '../../../../core/mock/mock_data.dart';
import '../../../../core/network/api_client.dart';
import '../../../../core/router/app_router.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/theme/app_text_styles.dart';
import '../../../../shared/widgets/bottom_nav_bar.dart';
import '../../../../shared/widgets/player_tile.dart';
import '../../../../shared/widgets/tab_scaffold.dart';
import '../../../community/presentation/community_controller.dart';
import '../discover_controller.dart';

class DiscoverScreen extends ConsumerStatefulWidget {
  const DiscoverScreen({super.key});

  @override
  ConsumerState<DiscoverScreen> createState() => _DiscoverScreenState();
}

class _DiscoverScreenState extends ConsumerState<DiscoverScreen> {
  String _filter = 'All';
  bool _promoShown = false;

  static const _center = LatLng(30.4278, -9.5981);

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _maybeShowPromo());
  }

  /// Shows the upcoming-event promo ONCE per app launch when entering Discover.
  Future<void> _maybeShowPromo() async {
    if (_promoShown || !mounted) return;
    try {
      final res = await ApiClient.instance.get('/events');
      final events = (res.data as List<dynamic>)
          .where((e) => (e['eventTime'] as int) >
          DateTime.now().millisecondsSinceEpoch)
          .toList()
        ..sort((a, b) => (a['eventTime'] as int)
            .compareTo(b['eventTime'] as int));
      if (events.isEmpty || !mounted) return;
      _promoShown = true;
      _showPromo(events.first as Map<String, dynamic>);
    } catch (_) {/* no promo on error */}
  }

  void _showPromo(Map<String, dynamic> e) {
    final dt = DateTime.fromMillisecondsSinceEpoch(e['eventTime'] as int);
    showDialog(
      context: context,
      barrierColor: Colors.black87,
      builder: (ctx) => Dialog(
        backgroundColor: AppColors.surface,
        insetPadding: const EdgeInsets.all(24),
        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20)),
        child: Stack(
          children: [
            Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // header image area (gradient + icon, like a promo image)
                Container(
                  height: 140,
                  width: double.infinity,
                  decoration: const BoxDecoration(
                    borderRadius: BorderRadius.vertical(
                        top: Radius.circular(20)),
                    gradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [Color(0xFF0E8A6D), Color(0xFF0B3D33)],
                    ),
                  ),
                  child: Center(
                    child: Icon(
                      _sportIcon(e['sport'] as String?),
                      size: 64,
                      color: Colors.white,
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(20),
                  child: Column(
                    children: [
                      if (e['sport'] != null)
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 10, vertical: 4),
                          decoration: BoxDecoration(
                            color: AppColors.primary,
                            borderRadius:
                            BorderRadius.circular(999),
                          ),
                          child: Text(
                            (e['sport'] as String).toUpperCase(),
                            style: AppTextStyles.button(size: 11),
                          ),
                        ),
                      const SizedBox(height: 10),
                      Text(e['title'] as String,
                          textAlign: TextAlign.center,
                          style: AppTextStyles.headline(size: 22)),
                      const SizedBox(height: 10),
                      Text(
                        '${dt.day}/${dt.month}/${dt.year} · ${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')} · ${e['place']}',
                        textAlign: TextAlign.center,
                        style: AppTextStyles.body(
                            size: 12, color: AppColors.textMuted),
                      ),
                      const SizedBox(height: 6),
                      Text('${e['joinedCount'] ?? 0} joined',
                          style: AppTextStyles.label(
                              size: 11, color: AppColors.primary)),
                      const SizedBox(height: 18),
                      GestureDetector(
                        onTap: () {
                          Navigator.pop(ctx);
                          context.push(AppRoutes.community);
                        },
                        child: Container(
                          width: double.infinity,
                          height: 48,
                          decoration: BoxDecoration(
                            color: AppColors.primary,
                            borderRadius:
                            BorderRadius.circular(999),
                          ),
                          child: Center(
                            child: Text('CHECK IT OUT',
                                style: AppTextStyles.button()),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            // close X
            Positioned(
              top: 8,
              right: 8,
              child: GestureDetector(
                onTap: () => Navigator.pop(ctx),
                child: Container(
                  width: 32,
                  height: 32,
                  decoration: const BoxDecoration(
                    color: Colors.black54,
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(Icons.close,
                      color: Colors.white, size: 18),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  IconData _sportIcon(String? sport) => switch (sport) {
    'Football' => Icons.sports_soccer,
    'Basketball' => Icons.sports_basketball,
    'Tennis' => Icons.sports_tennis,
    'Padel' => Icons.sports_tennis,
    'Running' => Icons.directions_run,
    'Cycling' => Icons.directions_bike,
    _ => Icons.emoji_events,
  };

  @override
  Widget build(BuildContext context) {
    final s = ref.watch(stringsProvider);
    final playersAsync = ref.watch(nearbyPlayersProvider(_filter));
    final players = playersAsync.value ?? []; // real, self already excluded

    return TabScaffold(
      current: AppTab.discover,
      child: ListView(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(s.discover, style: AppTextStyles.headline(size: 30)),
              GestureDetector(
                onTap: () => context.push(AppRoutes.notifications),
                child: Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: AppColors.surface,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: const Icon(Icons.notifications_outlined,
                      color: AppColors.text, size: 20),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),

          // Map with REAL player pins (everyone except the logged-in user)
          ClipRRect(
            borderRadius: BorderRadius.circular(16),
            child: SizedBox(
              height: 200,
              child: FlutterMap(
                options: const MapOptions(
                  initialCenter: _center,
                  initialZoom: 12.5,
                  interactionOptions:
                  InteractionOptions(flags: InteractiveFlag.all),
                ),
                children: [
                  TileLayer(
                    urlTemplate:
                    'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                    userAgentPackageName: 'com.trinimate',
                  ),
                  MarkerLayer(
                    markers: [
                      for (final p in players)
                        if (p['latitude'] != null &&
                            p['longitude'] != null)
                          Marker(
                            point: LatLng(
                              (p['latitude'] as num).toDouble(),
                              (p['longitude'] as num).toDouble(),
                            ),
                            width: 44,
                            height: 52,
                            // pin TIP sits exactly on the coordinates
                            alignment: const Alignment(0, 1),
                            child: GestureDetector(
                              onTap: () => context.push(
                                  '${AppRoutes.playerProfile}/${p['id']}'),
                              child: Column(
                                children: [
                                  Container(
                                    width: 34,
                                    height: 34,
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      color: AppColors.primary,
                                      border: Border.all(
                                          color: Colors.white,
                                          width: 2),
                                      boxShadow: const [
                                        BoxShadow(
                                          color: Colors.black45,
                                          blurRadius: 6,
                                        ),
                                      ],
                                    ),
                                    child: Center(
                                      child: Text(
                                        _initials(
                                            p['name'] as String? ??
                                                '?'),
                                        style: const TextStyle(
                                          color: Colors.white,
                                          fontWeight:
                                          FontWeight.w800,
                                          fontSize: 12,
                                        ),
                                      ),
                                    ),
                                  ),
                                  // pointer triangle
                                  CustomPaint(
                                    size: const Size(12, 10),
                                    painter: _PinPainter(),
                                  ),
                                ],
                              ),
                            ),
                          ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.place_outlined,
                  color: AppColors.textMuted, size: 14),
              const SizedBox(width: 4),
              Text('${players.length} players on the map',
                  style: AppTextStyles.body(
                      size: 12, color: AppColors.textMuted)),
            ],
          ),
          const SizedBox(height: 16),

          SizedBox(
            height: 38,
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: [
                for (final f in ['All', ...MockData.sports])
                  Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: _FilterChip(
                      label: f,
                      active: _filter == f,
                      onTap: () => setState(() => _filter = f),
                    ),
                  ),
              ],
            ),
          ),
          const SizedBox(height: 16),

          Text(s.nearbyPlayers,
              style: AppTextStyles.headline(size: 20)),
          const SizedBox(height: 12),

          playersAsync.when(
            loading: () => const Padding(
              padding: EdgeInsets.all(32),
              child: Center(
                child: CircularProgressIndicator(
                    color: AppColors.primary),
              ),
            ),
            error: (e, _) => Padding(
              padding: const EdgeInsets.symmetric(vertical: 24),
              child: Column(
                children: [
                  Text('Could not load players.',
                      textAlign: TextAlign.center,
                      style:
                      AppTextStyles.body(color: AppColors.textMuted)),
                  const SizedBox(height: 8),
                  GestureDetector(
                    onTap: () =>
                        ref.invalidate(nearbyPlayersProvider(_filter)),
                    child: Text('TAP TO RETRY',
                        style: AppTextStyles.label(
                            color: AppColors.primary)),
                  ),
                ],
              ),
            ),
            data: (list) => list.isEmpty
                ? Padding(
              padding:
              const EdgeInsets.symmetric(vertical: 24),
              child: Text(s.noPlayersNearby,
                  textAlign: TextAlign.center,
                  style: AppTextStyles.body(
                      color: AppColors.textMuted)),
            )
                : Column(
              children: [
                for (final p in list)
                  Padding(
                    padding:
                    const EdgeInsets.only(bottom: 10),
                    child: PlayerTile(
                      name: p['name'] as String? ?? 'Player',
                      pinged: ref
                          .watch(pingedIdsProvider)
                          .contains(p['id'] as int),
                      subtitle: () {
                        final sports = (p['sports']
                        as List<dynamic>?) ??
                            [];
                        final sportName = sports.isNotEmpty
                            ? sports[0]['sport']
                        as String? ??
                            ''
                            : '';
                        final dist = p['distanceKm'];
                        final distText = dist is num
                            ? '${dist.toStringAsFixed(1)} km away'
                            : 'nearby';
                        return sportName.isEmpty
                            ? distText
                            : '$sportName · $distText';
                      }(),
                      onTap: () => context.push(
                          '${AppRoutes.playerProfile}/${p['id']}'),
                      onPing: () async {
                        try {
                          final res = await ApiClient.instance
                              .post(
                              '/players/${p['id']}/ping',
                              data: {
                                'message': 'Want to play?'
                              });
                          final pinged =
                              (res.data['pinged'] as bool?) ??
                                  true;
                          final current =
                          Set<int>.from(ref.read(
                              pingedIdsProvider));
                          if (pinged) {
                            current.add(p['id'] as int);
                          } else {
                            current.remove(p['id'] as int);
                          }
                          ref
                              .read(pingedIdsProvider
                              .notifier)
                              .state = current;
                          if (!context.mounted) return;
                          ScaffoldMessenger.of(context)
                              .showSnackBar(SnackBar(
                            content: Text(pinged
                                ? 'Ping sent!'
                                : 'Ping removed'),
                          ));
                        } on DioException catch (e) {
                          if (!context.mounted) return;
                          ScaffoldMessenger.of(context)
                              .showSnackBar(SnackBar(
                            content: Text(e.response?.data?[
                            'error'] as String? ??
                                'Could not send ping'),
                          ));
                        }
                      },
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  String _initials(String name) {
    final parts = name.trim().split(' ');
    if (parts.length == 1) return parts.first.substring(0, 1).toUpperCase();
    return (parts[0][0] + parts[1][0]).toUpperCase();
  }
}

/// Triangle pointer under the avatar pin.
/// Triangle pointer under the avatar pin.
class _PinPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = AppColors.primary;
    final path = ui.Path()
      ..moveTo(0, 0)
      ..lineTo(size.width, 0)
      ..lineTo(size.width / 2, size.height)
      ..close();
    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _FilterChip extends StatelessWidget {
  const _FilterChip(
      {required this.label, required this.active, required this.onTap});

  final String label;
  final bool active;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 140),
        padding: const EdgeInsets.symmetric(horizontal: 16),
        decoration: BoxDecoration(
          color: active ? AppColors.primary : AppColors.surface2,
          borderRadius: BorderRadius.circular(999),
        ),
        child: Center(
          child: Text(label.toUpperCase(),
              style: AppTextStyles.button(
                  size: 12,
                  color: active ? Colors.white : AppColors.textMuted)),
        ),
      ),
    );
  }
}